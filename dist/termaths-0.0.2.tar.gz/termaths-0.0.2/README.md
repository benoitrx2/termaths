# Termaths

Termaths est un module qui est prévu pour les élèves de terminale en spécialité maths ou en maths experts.

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install foobar.

```bash
pip install foobar
```

## License
[MIT](https://choosealicense.com/licenses/mit/)
